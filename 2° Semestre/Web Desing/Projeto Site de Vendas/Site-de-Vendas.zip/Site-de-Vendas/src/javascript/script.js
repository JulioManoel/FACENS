var time = 5000;
var imageIndex = 0;
var images = document.querySelectorAll("#slider img");
var max = images.length;

function proximaImage(){
    images[imageIndex].classList.remove("selected");
    imageIndex++;
    if(imageIndex >= max){
        imageIndex = 0;
    }
    images[imageIndex].classList.add("selected");
}

function inicia(){
    setInterval(()=>{
        proximaImage();
    }, time)
}
window.addEventListener("load", inicia);