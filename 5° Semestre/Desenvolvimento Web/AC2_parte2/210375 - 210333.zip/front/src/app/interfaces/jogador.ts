export interface IJogador {
  _id: String,
  name: String,
  pokemon: String
}
