export interface IPokemon {
  results: Pokemon[]
}

export interface Pokemon {
  name: String,
  url: String
}
