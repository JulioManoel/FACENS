export class Carro {
    constructor (
        public id: number,
        public name: string,
        public year: number,
        public price: number
    ){}
}