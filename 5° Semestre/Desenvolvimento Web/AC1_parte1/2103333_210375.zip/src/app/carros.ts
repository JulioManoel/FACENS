import { Carro } from "./Carro"

export const carros: Carro[] = [
    new Carro(1, 'Celta', 2010, 12000),
    new Carro(2, 'Civic', 2020, 150000),
    new Carro(3, 'Saveiro', 2017, 70000)
]